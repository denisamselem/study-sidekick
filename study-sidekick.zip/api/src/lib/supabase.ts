import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL;
// FIX: Use the administrative service role key for all backend operations.
// This key bypasses Row-Level Security (RLS) policies, which is required
// for a trusted server to insert data into the database.
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
    throw new Error('Supabase URL and Service Key must be provided in environment variables for the backend.');
}

export const supabase = createClient(supabaseUrl, supabaseServiceKey);
